package com.noghostblock.client;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2561;
import net.minecraft.class_2846;
import net.minecraft.class_310;
import net.minecraft.class_634;

public class NoghostblockClient implements ClientModInitializer {

    @Override
    public void onInitializeClient() {
        // Регистрация команды /ghost для принудительного обновления области
        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) -> {
            dispatcher.register(
                    ClientCommandManager.literal("ghost").executes(context -> {
                        this.executeResync();
                        context.getSource().sendFeedback(class_2561.method_43470("§a[NoGhostBlock] Окружение синхронизировано!"));
                        return 1;
                    })
            );
        });
    }

    public void executeResync() {
        class_310 mc = class_310.method_1551();
        class_634 networkHandler = mc.method_1562();

        if (networkHandler == null || mc.field_1724 == null) return;

        class_2338 pos = mc.field_1724.method_24515();

        // Синхронизация области 9x9x9 вокруг игрока
        for (int dx = -4; dx <= 4; dx++) {
            for (int dy = -4; dy <= 4; dy++) {
                for (int dz = -4; dz <= 4; dz++) {
                    requestBlockUpdate(pos.method_10069(dx, dy, dz));
                }
            }
        }
    }

    public static void requestBlockUpdate(class_2338 pos) {
        class_310 client = class_310.method_1551();
        if (client.method_1562() != null) {
            client.method_1562().method_52787(new class_2846(
                    class_2846.class_2847.field_12971, pos, class_2350.field_11033
            ));
        }
    }
}