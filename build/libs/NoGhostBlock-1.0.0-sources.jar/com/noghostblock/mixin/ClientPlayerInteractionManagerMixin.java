package com.noghostblock.mixin;

import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2846;
import net.minecraft.class_310;
import net.minecraft.class_636;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_636.class)
public class ClientPlayerInteractionManagerMixin {

    @Inject(method = "breakBlock", at = @At("HEAD"))
    private void onBreakBlock(class_2338 pos, CallbackInfoReturnable<Boolean> cir) {
        class_310 mc = class_310.method_1551();
        if (mc.method_1562() != null) {
            // Запрос актуального состояния блока у сервера
            mc.method_1562().method_52787(new class_2846(
                    class_2846.class_2847.field_12971, pos, class_2350.field_11036
            ));
        }
    }
}